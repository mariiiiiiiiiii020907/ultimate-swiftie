import DATA from './questions.json' with {type:'json'};
export const ERAS=['Taylor Swift','Fearless','Speak Now','Red','1989','reputation','Lover','folklore','evermore','Midnights','The Tortured Poets Department','The Life of a Showgirl'];
const shuffle=a=>a.map(v=>[Math.random(),v]).sort((a,b)=>a[0]-b[0]).map(x=>x[1]);
const norm=s=>String(s).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]/g,'');
const requireThat=(v,m)=>{if(!v)throw Error(m)};
export function profile(b){requireThat(typeof b.name==='string'&&b.name.trim().length>0&&b.name.trim().length<=24,'Enter a name (1–24 characters).');requireThat(ERAS.includes(b.era),'Choose your favorite era.');requireThat(typeof b.song==='string'&&b.song.trim().length>0&&b.song.trim().length<=100,'Enter your favorite song (1–100 characters).');return {id:crypto.randomUUID(),name:b.name.trim(),era:b.era,song:b.song.trim(),lang:['en','pt','es','fr'].includes(b.lang)?b.lang:'en',score:0,correct:0,ready:false};}
export function create(p,hash,now=Date.now(),mode='group'){p.hash=hash;return {mode:mode==='solo'?'solo':'group',host:p.id,players:[p],status:mode==='solo'?'intro':'lobby',phase:0,index:0,used:[],answers:{},history:[],created:now};}
function pick(r,level){const pool=DATA.questions.filter(q=>!r.used.includes(q.id)&&q.level>=level);const q=shuffle(pool.length?pool:DATA.questions.filter(q=>!r.used.includes(q.id)))[0];r.used.push(q.id);return structuredClone(q);}
function setQ(r,q,now,seconds=25){r.roundScores=Object.fromEntries(r.players.map(p=>[p.id,{score:p.score,correct:p.correct}]));r.q=q;r.options=shuffle([q.answer,...q.wrong]);r.answers={};r.started=now;r.deadline=now+seconds*1000;r.nonce=crypto.randomUUID();r.status='question';}
function startQuestion(r,now){
 if(r.phase===1){const riddles=[{answer:'Enchanted',wrong:[],clues:{en:['A song from the original Speak Now album.','It is track nine.','Its one-word title begins with E.'],pt:['Uma música do álbum Speak Now original.','É a faixa nove.','O título tem uma palavra e começa com E.'],es:['Una canción del Speak Now original.','Es la pista nueve.','Su título empieza por E.'],fr:['Une chanson du Speak Now original.','C’est la piste neuf.','Son titre commence par E.']}},{answer:'All Too Well',wrong:[],clues:{en:['A song from the original Red album.','It is track five.','Its three-word title starts with All.'],pt:['Uma música do álbum Red original.','É a faixa cinco.','O título começa com All.'],es:['Una canción del Red original.','Es la pista cinco.','Su título empieza por All.'],fr:['Une chanson du Red original.','C’est la piste cinq.','Son titre commence par All.']}}];setQ(r,riddles[r.index],now,27);return;}
 if(r.phase===2){r.target=r.players[r.mode==='solo'?0:r.index].id;r.targetAnswer=null;r.thief=null;r.status='risk';r.deadline=now+12000;r.nonce=crypto.randomUUID();r.answers={};return;}
 if(r.phase===3&&r.mode==='solo'){setQ(r,pick(r,3),now,15);return;}
 if(r.phase===3){const p=r.players[r.index];r.subject=p.id;const isEra=r.index%2===0;const answer=isEra?p.era:p.song;const choices=shuffle((isEra?ERAS:r.players.map(x=>x.song).concat(['Enchanted','Style','Clean','Maroon','Love Story'])) .filter(x=>x!==answer));setQ(r,{answer,wrong:[...new Set(choices)].slice(0,3),favorite:true,isEra,subjectName:p.name},now);return;}
 if(r.phase===4){r.status='wager';r.deadline=now+20000;r.wagers={};r.nonce=crypto.randomUUID();return;}
 setQ(r,pick(r,1),now);
}
function reveal(r,now){r.status='reveal';r.deadline=0;r.revealed=now;r.history.push({phase:r.phase,index:r.index,answer:r.q?.answer});}
function eligible(r){return r.players.filter(p=>r.mode==='solo'||r.phase!==3||p.id!==r.subject);}
function award(p,points){p.score+=points;p.correct++;}
export function tick(r,now=Date.now()){
 if(!r.deadline||now<r.deadline)return;
 if(r.status==='risk'){r.risk=false;setQ(r,pick(r,2),now);}
 else if(r.status==='wager'){for(const p of r.players)if(!r.wagers[p.id])r.wagers[p.id]={amount:0,category:'music'};startFinal(r,now);}
 else if(r.status==='question'){
  if(r.phase===2&&r.mode==='solo'){if(r.risk)r.players[0].score-=13;reveal(r,now);}
  else if(r.phase===2){if(r.risk)r.players.find(p=>p.id===r.target).score-=13;r.status='steal';r.deadline=now+10000;r.answers={};r.nonce=crypto.randomUUID();}
  else {if(r.phase===4)for(const p of r.players)if(!r.answers[p.id])p.score-=r.wagers[p.id].amount;reveal(r,now);}
 }else if(r.status==='steal'||r.status==='stealAnswer')reveal(r,now);
}
function startFinal(r,now){r.roundScores=Object.fromEntries(r.players.map(p=>[p.id,{score:p.score,correct:p.correct}]));r.finals={};for(const p of r.players){const cat=r.wagers[p.id].category;const pool=DATA.questions.filter(q=>q.level>=2&&(cat==='life'?q.id<10||q.id>=35:q.id>=10&&q.id<35));r.finals[p.id]=structuredClone(shuffle(pool)[0]);}r.answers={};r.status='question';r.started=now;r.deadline=now+35000;r.nonce=crypto.randomUUID();}
export function act(r,p,b,now=Date.now()){
 tick(r,now);
 if(b.action==='join'){requireThat(r.mode!=='solo','This is a solo show. Create your own solo game.');requireThat(r.status==='lobby','This show has already started.');requireThat(r.players.length<8,'The room is full (8 players).');requireThat(!r.players.some(x=>norm(x.name)===norm(b.player.name)),'That name is already in this room.');r.players.push(b.player);return;}
 requireThat(p,'Your session has expired. Rejoin the room.');
 if(b.action==='ready'){requireThat(r.status==='lobby','Already started.');p.ready=!p.ready;return;}
 if(b.action==='start'){requireThat(p.id===r.host,'Only the host can start.');requireThat(r.status==='lobby'&&r.players.length>=2&&r.players.every(x=>x.ready),'At least two players must be ready.');r.status='intro';return;}
 if(b.action==='next'){requireThat(p.id===r.host,'Only the host can continue.');requireThat(['intro','reveal'].includes(r.status),'Wait for this round to finish.');if(r.status==='reveal'){const count=(r.mode==='solo'?[3,2,2,3,1]:[2,2,r.players.length,r.players.length,1])[r.phase];r.index++;if(r.index>=count){r.phase++;r.index=0;if(r.phase===5){r.status='finished';return;}r.status='intro';return;}}startQuestion(r,now);return;}
 requireThat(b.nonce===r.nonce,'The question changed. Try again.');
 if(b.action==='risk'){requireThat(r.status==='risk'&&p.id===r.target,'Wait for your turn.');r.risk=b.risk===true;setQ(r,pick(r,r.risk?3:1),now);return;}
 if(b.action==='wager'){requireThat(r.status==='wager'&&!r.wagers[p.id],'Wager already locked.');const amount=Number(b.amount);requireThat(Number.isInteger(amount)&&amount>=0&&amount<=Math.min(26,Math.max(0,p.score)),'Invalid wager.');r.wagers[p.id]={amount,category:b.category==='life'?'life':'music'};if(Object.keys(r.wagers).length===r.players.length)startFinal(r,now);return;}
 if(b.action==='buzz'){requireThat(r.status==='steal'&&p.id!==r.target,'You cannot steal now.');r.thief=p.id;r.status='stealAnswer';r.deadline=now+10000;return;}
 requireThat(b.action==='answer'&&['question','stealAnswer'].includes(r.status),'Answers are closed.');
 requireThat(!r.answers[p.id]?.locked,'Your answer is locked.');
 if(r.phase===3&&r.mode!=='solo')requireThat(p.id!==r.subject,'Your friends are guessing your favorite.');
 if(r.phase===2)requireThat(p.id===(r.status==='stealAnswer'?r.thief:r.target),'It is another player’s turn.');
 const q=r.phase===4?r.finals[p.id]:r.q;
 if(r.phase!==1&&r.phase!==4)requireThat(Number.isInteger(b.answer)&&b.answer>=0&&b.answer<r.options.length,'Choose a valid answer.');
 const guess=r.phase===1||r.phase===4?String(b.answer||'').slice(0,120):r.options[Number(b.answer)];
 requireThat(guess!==undefined,'Choose an answer.');
 const correct=norm(guess)===norm(q.answer);let points=0;
 if(r.phase===1){const step=Math.min(2,Math.floor((now-r.started)/8000));requireThat(r.answers[p.id]?.step!==step,'Wait for the next clue to guess again.');points=correct?[26,19,13][step]:0;r.answers[p.id]={guess,correct,locked:correct,step,points};if(correct)award(p,points);if(r.players.every(x=>r.answers[x.id]?.locked))reveal(r,now);return;}
 if(r.phase===2){if(r.status==='stealAnswer'){points=correct?8:0;if(correct)award(p,points);r.answers[p.id]={guess,correct,locked:true,points};reveal(r,now);return;}points=correct?(r.risk?26:13):(r.risk?-13:0);if(correct)award(p,points);else p.score+=points;r.targetAnswer={guess,correct,points};if(correct||r.mode==='solo')reveal(r,now);else{r.status='steal';r.deadline=now+10000;r.answers={};r.nonce=crypto.randomUUID();}return;}
 points=correct?13+((r.phase===0||(r.phase===3&&r.mode==='solo'))?Math.max(0,5-Math.floor((now-r.started)/4000)):0):0;
 if(r.phase===4)points=correct?13+r.wagers[p.id].amount:-r.wagers[p.id].amount;
 if(correct)award(p,points);else p.score+=points;
 r.answers[p.id]={guess,correct,locked:true,points};if(eligible(r).every(x=>r.answers[x.id]?.locked))reveal(r,now);
}
export function view(r,p,now=Date.now()){
 const v={mode:r.mode||'group',total:r.mode==='solo'?11:null,status:r.status,phase:r.status==='lobby'?null:r.phase,index:r.index,host:r.host,me:p.id,players:r.players.map(x=>({id:x.id,name:x.name,score:!['lobby','intro','reveal','finished','risk','wager'].includes(r.status)?r.roundScores?.[x.id]?.score??x.score:x.score,ready:x.ready,correct:!['lobby','intro','reveal','finished','risk','wager'].includes(r.status)?r.roundScores?.[x.id]?.correct??x.correct:x.correct})),nonce:r.nonce,deadline:r.deadline,serverNow:now,answered:Object.keys(r.answers||{}).filter(id=>r.answers[id].locked),target:r.target,subject:r.subject,thief:r.thief,mine:r.answers?.[p.id]?{locked:r.answers[p.id].locked,step:r.answers[p.id].step}:null,wagered:!!r.wagers?.[p.id]};
 if(['question','reveal','steal','stealAnswer'].includes(r.status)){
  const q=r.phase===4?r.finals[p.id]:r.q;const tr=q.translations?.[p.lang];
  v.question={prompt:tr?.prompt||q.prompt||'',options:r.phase===1||r.phase===4?null:r.options,favorite:q.favorite,isEra:q.isEra,subjectName:q.subjectName};
  if(r.phase===1){const step=Math.min(2,Math.floor((now-r.started)/8000));v.question.clues=(q.clues[p.lang]||q.clues.en).slice(0,step+1);v.question.step=step;}
  if(r.status==='reveal'){v.question.answer=q.answer;v.question.explanation=tr?.explanation||q.explanation||'';v.results=r.players.map(x=>({id:x.id,...(r.answers[x.id]||{}),...(x.id===r.target&&r.phase===2?r.targetAnswer:{})}));v.question.source=DATA.sources[q.source]||null;}
 }
 return v;
}
