import {create,profile,act,tick,view} from './engine.mjs';
const json=(v,status=200)=>Response.json(v,{status,headers:{'Cache-Control':'no-store'}});
async function hash(s){return [...new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s)))].map(x=>x.toString(16).padStart(2,'0')).join('');}
export async function handle(db,req){try{
 const body=req.method==='POST'?await req.json():{};const url=new URL(req.url);const code=String(body.code||url.searchParams.get('room')||'').toUpperCase();
 if(req.method==='POST'&&req.headers.get('origin')&&new URL(req.headers.get('origin')).origin!==url.origin)return json({error:'Invalid origin'},403);
 if(body.action==='create'){
  const p=profile(body),token=crypto.randomUUID()+crypto.randomUUID();const state=create(p,await hash(token),Date.now(),body.mode);
  await db.prepare('DELETE FROM rooms WHERE expires < ?').bind(Date.now()).run();
  for(let i=0;i<5;i++){const c=Array.from(crypto.getRandomValues(new Uint8Array(6)),x=>'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'[x%32]).join('');try{await db.prepare('INSERT INTO rooms (code,revision,state,expires) VALUES (?,0,?,?)').bind(c,JSON.stringify(state),Date.now()+86400000).run();return json({code:c,token,state:view(state,p)});}catch(e){if(i===4)throw e;}}
 }
 if(!/^[A-Z2-9]{6}$/.test(code))return json({error:'Enter a six-character room code.'},400);
 const token=req.headers.get('authorization')?.replace(/^Bearer /,'')||'';const h=await hash(token);
 const joining=body.action==='join'&&req.method==='POST';const newToken=joining?crypto.randomUUID()+crypto.randomUUID():null;const newPlayer=joining?profile(body):null;if(newPlayer)newPlayer.hash=await hash(newToken);
 for(let i=0;i<12;i++){
 const row=await db.prepare('SELECT * FROM rooms WHERE code=? AND expires>?').bind(code,Date.now()).first();if(!row)return json({error:'Room not found or expired.'},404);
 const state=JSON.parse(row.state);let p=state.players.find((x)=>x.hash===h);if(!joining&&!p)return json({error:'Session not found on this device. Rejoin from the lobby.'},401);
 tick(state);
 if(joining){act(state,null,{action:'join',player:newPlayer});p=newPlayer;}else if(req.method==='POST')act(state,p,body);
 const result=await db.prepare('UPDATE rooms SET state=?,revision=revision+1 WHERE code=? AND revision=?').bind(JSON.stringify(state),code,row.revision).run();
 if(result.meta.changes)return json({code,...(joining?{token:newToken}:{}),state:view(state,p)});
 }
 return json({error:'Busy room. Please try again.'},409);
 }catch(e){return json({error:e instanceof Error?e.message:'Unable to connect.'},400);}}

