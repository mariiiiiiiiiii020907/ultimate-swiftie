# The Ultimate Swiftie — Afterglow Studios

A mobile-friendly online game with Solo (1 player) and Friends (2–8 players) modes. Each player uses their own phone and joins a shared six-character room. The host advances reveals and acts. Rooms expire after 24 hours. Refreshing the same browser tab resumes a session.

## Current implementation

- Opening with the approved 3D animated concert performer in a lavender bodysuit, headline, Enter button.
- English, Brazilian Portuguese, Spanish and French per player.
- Private favorite era and song collected before joining.
- Five hidden acts, revealed individually with original phrases and animated entrances.
- Simultaneous trivia with speed bonuses; gradual song clues; safe/risk turns and first-come steals; friends’ favorites; secret final categories and point wagers.
- Server-authoritative scoring and timers, question nonces, hashed session tokens, durable D1 rooms and optimistic concurrency retries.
- A 50-question bank with explanations, source links and translated prompts. A match uses a subset; questions are randomized within difficulty constraints. Riddle round currently has two fixed riddles.
- Original synthesized instrumental ambience, enabled by user interaction. No Taylor audio recordings bundled.

## Main files

`public/game.html`: complete game interface, inline CSS and JavaScript.
`public/assets/`: optimized concert and act backgrounds.
`server/engine.mjs`: game rules, score calculation and public-state redaction.
`server/api.mjs`: HTTP handler, session hashing and atomic database persistence.
`server/questions.json`: question bank, translations and source references (server only).
`app/api/game/route.ts`: Cloudflare runtime adapter.
`db/schema.ts`, `drizzle/`: schema and immutable generated migrations.
`server/*.test.mjs`: game flow, authorization, timeouts, redaction and concurrent API updates.
`public/offline.html`: older offline edition; does not synchronize phones and does not contain the new multiplayer rules.
`src/`: historical offline source. Do not run its old build scripts over the current Worker build.

## Local development (Node 22.13+)

1. `npm ci`
2. `npm run build`
3. `node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0000_premium_the_professor.sql`
4. `npm run dev`
5. Open the development URL printed by the CLI. Create a room in one browser, join using another browser/device or the invitation URL. Phones must be able to reach your server; localhost on a phone points to that phone, not your computer.

Run `node --test server/*.test.mjs` for the automated checks. Schema changes: edit db/schema.ts, run `npm run db:generate`, inspect new SQL, and apply new migrations locally. Never change migration history after deployment.

## Hosting

This is a Vinext/Cloudflare Worker application with a D1 binding named DB, not just a static HTML page. Sites provisions the hosted binding and applies migrations. Keep the existing project's identity and sharing when updating that hosted project. For another provider, configure your own Worker/D1 deployment, supply its database binding, and apply migrations before launch. The frontend still needs the same-origin `/api/game` endpoint. Do not upload only game.html and expect multiplayer to work.

## Not yet connected

Whop checkout, authenticated Whop identities and purchase/entitlement checks are NOT integrated. This build is a gameplay preview. A room code is NOT proof of payment. Before selling per-player access, implement server-verified Whop identity and active product entitlement for each player at create/join and resume; bind game sessions to those identities. Keep all Whop secrets server-side. A static payment link, client boolean or shared code cannot enforce per-player purchases.

The existing hosted review remains owner-private. Friends/customers need an explicitly selected hosting audience and the above purchase integration before a paid launch. Keep this restriction in place during further AI edits unless the owner authorizes a change.

Do not claim official Taylor Swift affiliation. The stage art is stylized fan-game artwork. Question sources are in the data file; verify time-sensitive additions when extending the bank.

## Solo mode
After Enter choose Play solo, complete your profile and start immediately. Eleven challenges across five hidden acts: 3 opening trivia, 2 clue songs, 2 safe/risk questions, 3 difficult 15-second sprint questions, and one final wager. No friends, readiness lobby, stealing or room sharing is needed. Timers remain server-controlled. Final score, accuracy and the device’s personal best are displayed. Personal best is browser-local, not a verified global leaderboard. Solo still needs the online backend.


This repository exports the current online Solo and Friends game. Historical offline source and the old offline playable HTML were intentionally excluded. Read WHOP_START_HERE.md for the purchase integration handoff.
