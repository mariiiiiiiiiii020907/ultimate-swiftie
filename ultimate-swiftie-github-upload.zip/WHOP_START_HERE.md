# The Ultimate Swiftie — Whop integration handoff

## Current status

This package contains the latest deployed game source, including Solo and Friends modes. Gameplay is implemented. Whop authentication, purchase checks, checkout links and Whop hosting are NOT yet implemented or connected. This handoff is not a paid-access implementation and must not be described as one.

The owner currently reviews the game at https://ultimate-swiftie-mariana.raremoth9.chatgpt.site. That deployment remains owner-private; preserve it while preparing a separate Whop integration. The current source commit is ead8e693ccf013a82507bfcbe427870b602f68dc.

## Architecture

- Vinext application with Next.js-style App Router routes; React 19, Vite and a Cloudflare Worker runtime.
- `public/game.html`: interface, inline CSS and JavaScript, four languages, approved concert imagery. It calls same-origin `/api/game`.
- `app/api/game/route.ts`: route adapter, currently passes the Cloudflare D1 DB binding to the handler.
- `server/api.mjs`: create/join/poll/action HTTP handler. This is the central integration point for verified Whop identity and purchase access.
- `server/engine.mjs`: authoritative phase changes, timers, private answer checks, scoring, clue progression, risk/steal mechanics, final wagers and public-state redaction.
- `server/questions.json`: server-only questions, answers, translations and source references. Never serve this file publicly.
- `db/schema.ts` and `drizzle/`: rooms table and generated migrations. Rooms hold a JSON game state, revision counter and 24-hour expiration. Updates use compare-and-swap revision checks with retry to preserve simultaneous responses.
- Current sessions: randomly generated player tokens; only SHA-256 hashes are stored in room state. Tokens identify a game player, not a verified buyer. They are NOT a purchase gate.
- New source includes 1-player Solo and 2–8-player Friends modes. Preserve both and English, Portuguese, Spanish and French.

A single static HTML upload is insufficient. The browser interface needs the server endpoint and database. If Whop hosting does not support Cloudflare Worker/D1 bindings, port the thin runtime/database adapter while preserving the engine and atomic room updates. Inspect the hosting target before choosing a migration strategy.

## What to build next

1. Select the owner's actual Whop app, product and checkout. Confirm sandbox vs production. Do not create duplicate products or guess identifiers.
2. Configure Sign in with Whop using the current official OAuth 2.1/PKCE documentation, or the documented signed user-token flow if deploying as an embedded Whop app. Do not trust an unsigned user ID/header from a browser.
3. Keep OAuth credentials and any entitlement API key in server secret settings. Never put them in `public/`, URLs, browser storage, the exported ZIP or chat messages.
4. Implement short-lived server-validated user sessions. OAuth state/PKCE validation and secure HttpOnly session cookies are required for the web login flow. Preserve the invitation room code through login using a validated internal return path.
5. Before creating a Solo game, creating a Friends room, joining a room, resuming or submitting a game action, verify the current authenticated person's entitlement to the exact game product. Recheck active access on a documented bounded schedule; deny on invalid identity, expired sessions, missing configuration, provider errors or revoked access. Do not store a permanent client-side `paid: true` flag.
6. Bind each player to the authenticated Whop user ID in server room state. A game token must only work for that same authenticated identity. One buyer must not occupy multiple player slots in the same room. Do not expose other players' Whop identity data in public views.
7. Existing preview players have no Whop identity. They must not become paid players automatically: expire/reject those sessions in paid mode and require verified sign-in.
8. Room codes only locate rooms. They never authorize access or demonstrate payment. Every participant needs independent verified access.
9. Add a login/purchase-required screen in all four languages, using the actual product checkout and a retry path after purchase. Do not show a successful purchase until Whop confirms it server-side.
10. IMPORTANT: `public/offline.html` is an archived playable offline edition. Remove it from the paid deployment or protect its distribution; leaving it publicly downloadable can bypass the intended paid access. Historical `src/` files are reference material, not the current deployed app.

## Real configuration still needed

- Public product/checkout URL and exact product ID.
- Whop app ID and choice of standalone website OAuth vs embedded app.
- Registered callback URI for the chosen hosting target.
- Appropriate server-side API permissions and secret configuration.
- Sandbox buyer and non-buyer test accounts, then production configuration.

Do not ask the owner to paste private API keys or client secrets into chat. Guide them to the hosting provider's secret settings.

## Validation and launch

The current gameplay tests can be run with `node --test server/*.test.mjs` on Node 22.13+. They do not test Whop because it is not connected.

After implementation, test against Whop's sandbox: logged-out user denied; authenticated non-buyer denied; buyer can complete Solo; buyer can host Friends; second verified buyer can join and finish; non-buyer with a valid room code denied; stolen game token from a different identity denied; duplicate identity/player slot denied; refunded/revoked access denied on recheck; missing configuration and API failure deny access; reconnect and invitation redirect work; all four languages remain playable. Use controlled mocks for failure paths as well, but do not call mocked checks a real purchase test.

Only after the real checks pass, configure the owner's selected audience, product visibility and actual checkout button. Keep review access private until the owner explicitly requests the paid public launch. This handoff does not publish or change anything on the Whop account.

## Official references reviewed 2026-11-06

- https://docs.whop.com/developer/guides/oauth
- https://docs.whop.com/llms.txt
- https://whop.com/blog/add-user-authentication/
- https://whop.com/blog/add-paywall/

Consult the current API reference before implementing exact entitlement endpoint calls. No endpoint or credential is fabricated in this handoff.
