# Brief for the next AI

Continue this project; preserve the purple/gold, elegant animated concert aesthetic and approved jeweled purple bodysuit performer. Opening should contain only performer, provocative headline and Enter (plus optional audio toggle). No overview that spoils future acts.

The core goal is a FUN phone-per-player Swiftie party game, eventually sold through Whop per player. Preserve server-side answers, authoritative timers and scoring, private favorites/wagers, duplicate-answer protection, and optimistic database updates. Never move the question answer bank into the client. Preserve all four languages and accessibility/reduced-motion support.

Gameplay and UI are implemented. Existing tests pass, and two browsers were checked in different languages for room joining, ready/start, private answers, speed scoring and shared reveal. Improve game variety and riddle replayability if requested. Do not claim large-scale load testing or paid-access readiness.

Remaining product integration: real Whop sign-in/purchase verification per player, explicit launch audience, operational anti-abuse controls for public traffic, and a host recovery/reassignment experience if requested. The current host must remain available to advance the show. There is no Whop API secret, paid membership integration or product URL in this package. Obtain the owner's product identifier and use the current official Whop integration documentation; do not invent a client-side paywall.

Start by reading README.md and then public/game.html, server/engine.mjs, server/api.mjs and the tests. Run tests after changing scoring, privacy, timers or persistence. The HTML contains its CSS and JavaScript, but real multiplayer requires the backend and database. Do not misrepresent the archived offline version as the multiplayer edition.

Solo mode has now been added alongside group play. Preserve the mode chooser after Enter, immediate single-player start, 11-challenge flow, no-steal solo risk turns, deep-cut sprint replacing friends’ favorites, and the solo score/accuracy/device-best ending. Test both modes when changing shared engine code.
