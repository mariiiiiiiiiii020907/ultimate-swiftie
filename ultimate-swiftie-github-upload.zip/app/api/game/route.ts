import {env} from 'cloudflare:workers';
import {handle} from '../../../server/api.mjs';
export const dynamic='force-dynamic';
export const GET=(request:Request)=>handle((env as any).DB,request);
export const POST=GET;
