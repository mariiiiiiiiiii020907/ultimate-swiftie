import { sqliteTable, text, integer, index } from 'drizzle-orm/sqlite-core';
export const rooms = sqliteTable('rooms', {code:text('code').primaryKey(), revision:integer('revision').notNull().default(0), state:text('state').notNull(), expires:integer('expires').notNull()}, t=>[index('rooms_expiry').on(t.expires)]);
